# Memoirs Jekyll Theme by WowThemes - Change Log

## 2020-04-07, v1.0.1
- responsive tweaks

## 2020-04-04, v1.0.0

